# 📦 Hướng dẫn Triển khai Lên Hosting
# Website: naobokhoemanh.io.vn

---

## 🗂️ Danh sách CÁC FILE cần tải lên Hosting

```
landing_page/
├── index.html          ← Trang chủ (Landing Page)
├── admin.html          ← Trang quản trị admin
├── checkout.html       ← Trang thanh toán
├── admin_server.py     ← Máy chủ chính (QUAN TRỌNG NHẤT)
├── style.css           ← Thiết kế giao diện
├── main.js             ← JavaScript trang chủ
└── brain.db            ← Database (tự tạo khi chạy lần đầu)
```

> **LƯU Ý:** File `brain.db` sẽ tự tạo tự động nếu chưa có. Bạn không cần lo.

---

## ⚡ Cách Triển khai

### Phương án A: Hosting có cPanel (Đơn giản nhất)

1. **Đăng nhập vào cPanel** của bạn.
2. Vào **File Manager** → Mở thư mục `public_html`.
3. **Upload toàn bộ file** trong thư mục `landing_page` vào `public_html`.
4. Vào **Setup Python App** (thường nằm trong phần Software):
   - Chọn Python version: **3.9+**
   - Application root: `public_html`
   - Application startup file: `admin_server.py`
   - Bấm **Create** hoặc **Start**.

### Phương án B: VPS (Qua SSH)

1. **Kết nối SSH** vào VPS của bạn.
2. Chạy các lệnh sau:
    ```bash
    # Tạo thư mục và upload file
    mkdir -p /var/www/naobokhoemanh
    # (Tải file lên bằng SFTP hoặc SCP)

    # Cài đặt dependencies
    cd /var/www/naobokhoemanh
    pip install -r requirements.txt   # (Nếu có)

    # Chạy server (sử dụng gunicorn hoặc screen/tmux)
    python admin_server.py
    ```

3. **Cấu hình Nginx/Apache** để trỏ tên miền về cổng `8080`.

---

## 🔐 Cấu hình Bảo mật Webhook (QUAN TRỌNG)

Sau khi deploy, bạn cần cập nhật cấu hình Webhook trên SePay:

1. Vào **SePay → Tích hợp Webhooks**.
2. **Sửa** webhook đã tạo.
3. Đặt **URL**: `https://naobokhoemanh.io.vn/api/sepay-webhook`
4. Tại phần **Token Xác thực**, nhập: `naobokhoemanh_secret_2024`
5. Bấm **Lưu**.

> Nếu muốn đổi Token, hãy sửa dòng `SEPAY_WEBHOOK_TOKEN` trong file `admin_server.py` và cập nhật trong SePay.

---

## ✅ Kiểm tra sau khi triển khai

Mở trình duyệt và truy cập các địa chỉ sau để xác nhận mọi thứ hoạt động:

| Địa chỉ | Kết quả mong đợi |
|---------|-----------------|
| `https://naobokhoemanh.io.vn/` | Trang Landing Page hiển thị |
| `https://naobokhoemanh.io.vn/thanh-toan` | Trang Thanh toán hiển thị |
| `https://naobokhoemanh.io.vn/admin` | Trang Quản trị Admin hiển thị |
| `https://naobokhoemanh.io.vn/api/products` | Hiện JSON danh sách sản phẩm |

---

## 🆘 Cần hỗ trợ?

Nếu gặp vấn đề khi triển khai, hãy cung cấp thông tin:
- Loại Hosting bạn đang dùng (cPanel, DirectAdmin, VPS...).
- Thông báo lỗi nếu có.

